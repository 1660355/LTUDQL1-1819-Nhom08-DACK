﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTO_QuanLyVeXe
{
    public class User
    {
        public int iD;

        public int ID
        {
            get { return iD; }
            set { iD = value; }
        }
        public string maTuyen;

        public string MaTuyen
        {
            get { return maTuyen; }
            set { maTuyen = value; }
        }
        public string diemDi;

        public string DiemDi
        {
            get { return diemDi; }
            set { diemDi = value; }
        }
        public string diemDen;

        public string DiemDen
        {
            get { return diemDen; }
            set { diemDen = value; }
        }
        public DateTime thoiGian;

        public DateTime ThoiGian
        {
            get { return thoiGian; }
            set { thoiGian = value; }
        }
        
    }
}
