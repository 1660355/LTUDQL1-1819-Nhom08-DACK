﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace DAO_QuanLyVeXe
{
    class Provider
    {
        string strSql;
        public Provider()
        {
            strSql = "Data Source = LUANHUYNH-PC\\SQL; Initial Catalog=QLTuyenXeDB; UID = sa ; PWD = hvpk;";
        }
        public SqlConnection getConnect()
        {
            return new SqlConnection(strSql);
        }
    }
}
