﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DTO_QuanLyVeXe;
using System.Data;
using System.Data.SqlClient;

namespace DAO_QuanLyVeXe
{
    public class UserDAO
    {
        Provider pv;
        SqlDataAdapter da;
        SqlCommand cmd;
        public UserDAO()
        {
            pv = new Provider();
        }
        public DataTable getAllTuyenXe()
        {
            string strSql = "SELECT * FROM TuyenXe";
            SqlConnection connect = pv.getConnect();
            da = new SqlDataAdapter(strSql, connect);
            connect.Open();
            DataTable dt = new DataTable();
            da.Fill(dt);
            connect.Close();
            return dt;
        
        }

        //public static void Insert(User user)
        //{
           

        //}
        public bool EditTuyenXe(User user)
        {

            string strSql = "UPDATE TuyenXe SET MaTuyen = @MaTuyen , DiemDi = @DiemDi , DiemDen = @DiemDen , ThoiGian = @ThoiGian WHERE Id = @Id ";
            SqlConnection connect = pv.getConnect();
            try
            {
                cmd = new SqlCommand(strSql, connect);
                connect.Open(); 
                cmd.Parameters.Add("@Id", SqlDbType.Int).Value = user.ID;
                cmd.Parameters.Add("@MaTuyen", SqlDbType.VarChar).Value = user.MaTuyen;

                cmd.Parameters.Add("@ThoiGian", SqlDbType.DateTime).Value = user.ThoiGian;

                cmd.Parameters.Add("@DiemDi", SqlDbType.NVarChar).Value = user.DiemDi;
                cmd.Parameters.Add("@DiemDen", SqlDbType.NVarChar).Value = user.DiemDen;


                cmd.ExecuteNonQuery();
                connect.Close();
            }
            catch (Exception)
            {
                return false;
            }
            return true;
        }
        public bool InsertTuyenXe(User user)
        {

            string strSql = "INSERT INTO TuyenXe VALUES (@MaTuyen , @DiemDi , @DiemDen ,  @ThoiGian) ";
            SqlConnection connect = pv.getConnect();
            try
            {
                cmd = new SqlCommand(strSql, connect);
                connect.Open();
                
                cmd.Parameters.Add("@MaTuyen", SqlDbType.VarChar).Value = user.MaTuyen;

                cmd.Parameters.Add("@ThoiGian", SqlDbType.DateTime).Value = user.ThoiGian;

                cmd.Parameters.Add("@DiemDi", SqlDbType.NVarChar).Value = user.DiemDi;
                cmd.Parameters.Add("@DiemDen", SqlDbType.NVarChar).Value = user.DiemDen;


                cmd.ExecuteNonQuery();
                connect.Close();
            }
            catch (Exception)
            {
                return false;
            }
            return true;
        }
        //public static void Delete(int Id)
        //{
           

        //}
    }
}
