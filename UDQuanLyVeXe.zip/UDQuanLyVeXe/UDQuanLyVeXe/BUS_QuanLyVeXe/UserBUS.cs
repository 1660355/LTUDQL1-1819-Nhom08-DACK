﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DTO_QuanLyVeXe;
using DAO_QuanLyVeXe;
using System.Data;
using System.Data.SqlClient;

namespace BUS_QuanLyVeXe
{
    public class UserBUS
    {
        UserDAO userDAO;
        public UserBUS()
        {
            userDAO = new UserDAO();
        }
        public DataTable getAllTuyenXe()
        {
            return userDAO.getAllTuyenXe();
        }
        public bool EditTuyenXe(User user)
        {
            return userDAO.EditTuyenXe(user);
        }
        public bool InsertTuyenXe(User user)
        {
            return userDAO.InsertTuyenXe(user);
        }
    }
}
