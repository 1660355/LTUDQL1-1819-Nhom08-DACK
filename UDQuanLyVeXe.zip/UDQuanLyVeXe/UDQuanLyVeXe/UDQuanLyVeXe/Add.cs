﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BUS_QuanLyVeXe;
using DTO_QuanLyVeXe;
using System.Data.SqlClient;

namespace UDQuanLyVeXe
{
    public partial class Add : Form
    {
        UserBUS userBUS;
        
        public Add()
        {
            InitializeComponent();
            userBUS = new UserBUS();
        }

        private void btnTrove_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 frm1 = new Form1();
            frm1.Show();
        }
        public bool CheckData()
        {
            if (string.IsNullOrEmpty(txtMaTuyen.Text))
            {
                MessageBox.Show("Bạn Chưa Nhập Mã Tuyến", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtMaTuyen.Focus();
                return false;
            }
            if (string.IsNullOrEmpty(txtDiemDi.Text))
            {
                MessageBox.Show("Bạn Chưa Nhập Điểm Đi", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtDiemDi.Focus();
                return false;
            }
            if (string.IsNullOrEmpty(txtDiemDen.Text))
            {
                MessageBox.Show("Bạn Chưa Nhập Điểm Đến", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                txtDiemDen.Focus();
                return false;
            }
            return true;
        }
        
        
        
        private void btnThem_Click(object sender, EventArgs e)
        {
            if (CheckData())
            {
                User user = new User();
                
                user.MaTuyen = txtMaTuyen.Text;

                user.ThoiGian = DateTime.Parse(dtThoiGian.Text);

                user.DiemDi = txtDiemDi.Text;
                user.DiemDen = txtDiemDen.Text;


                if (userBUS.InsertTuyenXe(user))
                {

                    Form1 frm = new Form1();
                    frm.ShowAllTuyenXe();
                    MessageBox.Show("Đã Thêm Thành Công!", "Thông Báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("Đã có lổi xảy ra. Xin thử lại sau!", "Thông Báo Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }
            }
        }
    }
}
