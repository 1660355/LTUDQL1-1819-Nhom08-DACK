﻿using DevExpress.XtraBars;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using BUS_QuanLyVeXe;
using DTO_QuanLyVeXe;


namespace UDQuanLyVeXe
{
    public partial class Form1 : DevExpress.XtraBars.FluentDesignSystem.FluentDesignForm
    {

        UserBUS userBus;
        public Form1()
        {
            InitializeComponent();
            userBus = new UserBUS();
        }
        public void ShowAllTuyenXe()
        {
            DataTable dt = userBus.getAllTuyenXe();
            dtgvtttx.DataSource = dt;
        }
        private void Form1_Load_1(object sender, EventArgs e)
        {
            ShowAllTuyenXe();
        }

        private void spbtnThem_Click(object sender, EventArgs e)
        {
            this.Hide();
            Add add = new Add();
            add.Show();   
        }
        int ID;
        public void Edit(DataGridView data)
        {
            DataGridViewRow row = data.SelectedCells[0].OwningRow;
            User user = new User();
            user.ID = Int32.Parse(row.Cells["Id"].Value.ToString());
            user.MaTuyen = row.Cells["MaTuyen"].Value.ToString();
            user.DiemDi = row.Cells["DiemDi"].Value.ToString();
            user.DiemDen = row.Cells["DiemDen"].Value.ToString();
            user.ThoiGian = (DateTime)row.Cells["ThoiGian"].Value;
            userBus.EditTuyenXe(user);
        }

        private void spbtnSua_Click(object sender, EventArgs e)
        {
            Edit(dtgvtttx);
            ShowAllTuyenXe();
        }
       
    }
}
